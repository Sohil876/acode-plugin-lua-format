## acode-lua-format

Supports Lua 5.1 - 5.4, FiveM hashed strings & a touch of Luau\
Using [luamin.js](https://github.com/Herrtt/luamin.js)

### Installation

For now, download dist.zip from this repo, go to `Acode > Settings > Plugins > Local` to browse and select dist.zip and click install. 

### License

[MIT](https://choosealicense.com/licenses/mit/)
